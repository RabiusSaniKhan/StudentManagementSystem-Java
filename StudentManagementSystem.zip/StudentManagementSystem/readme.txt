You have to create a database named 'studentappdb'
Then import database from folder sampledatabase/studentappdb.sql
and then connet with database with project using IDE

Ola---- It's work