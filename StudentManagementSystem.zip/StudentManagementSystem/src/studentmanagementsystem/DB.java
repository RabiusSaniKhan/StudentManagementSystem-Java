/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentmanagementsystem;

import java.sql.*;

/**
 *
 * @author Sani Khan
 */
public class DB {
    public static Connection getConnection() throws SQLException {
        
        try {
        Class.forName("com.mysql.jdbc.Driver");  
        Connection connect = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/studentappdb","root",""); 
        return connect;
        }
        catch (ClassNotFoundException ex) {
           return  null; 
        }
        
    }
}
